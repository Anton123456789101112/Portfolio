#include <iostream>
#include <windows.h>
#include <string>
#include <thread>

using namespace std;

// <- X     Y ^

class ClassPlayer
{
public:
    int BottomSideY;
    int SideY1, SideY2, SideY3, SideY4;
    int LeftSideX, BottomSideX, RightSideX;
    bool PlayerSpawn;

    void MovePlayerRight()
    {
        LeftSideX++;
        BottomSideX++;
        RightSideX++;
    }
    void MovePlayerLeft()
    {
        LeftSideX--;
        BottomSideX--;
        RightSideX--;
    }
};

class ClassApple
{
public:
    int AppleY1, AppleY2, AppleY3;
    int AppleX1, AppleX2;

    int RandomAppleX;
    int AppleSpeed;
    bool AppleB;

    void MoveAppleDown()
    {
        AppleY1++;
        AppleY2++;
        AppleY3++;
    }
    void ResetApple()
    {
        AppleY1 = 1;
        AppleY2 = 2;
        AppleY3 = 3;
    }
};

void Draw(string Str, int X, int Y, WORD color);

void ErasePlayer(void);
void DrawPlayer(void);

void DrawApple(void);
void EraseApple(void);

void EraseAll(void);
void StartMenu(void);
void DrawBackground(void);
bool LOL = false;
bool StartOrEndMenu = false;

// Timers:
int PlayerTimer1 = 0;
int PlayerTimer2 = 0;
int PlayerElapsed = 0;

int AppleFallTimer1 = 0;
int AppleFallTimer2 = 0;
int AppleFallElapsed = 0;

int AppleSpeedTimer1 = 0;
int AppleSpeedTimer2 = 0;
int AppleSpeedElapsed = 0;

void StartTimers(void);
void TimerStuff(void);

// Colors:
int BackgroundRed = 64;
int BackgroundGray = 128;
int BackgroundGreen = 160;

int Score = 0;

void CrunchV() {
    PlaySound("NewCrunch.wav", NULL, SND_FILENAME|SND_ASYNC);
}

ClassApple apple;
ClassPlayer player;

int main()
{
    player.PlayerSpawn = true;
    player.BottomSideY = 27;
    player.SideY1 = 23;
    player.SideY2 = 24;
    player.SideY3 = 25;
    player.SideY4 = 26;
    player.LeftSideX = 50;
    player.BottomSideX = 50;
    player.RightSideX = 57;


    srand(GetTickCount());                      // Randomizer
    apple.RandomAppleX =  ((rand() % 100) + 5); // 5-100?
    apple.AppleX1 = apple.RandomAppleX;
    apple.AppleX2 = apple.AppleX1 + 1;

    apple.AppleY1 = 1;
    apple.AppleY2 = 2;
    apple.AppleY3 = 3;
    apple.AppleSpeed = 100;
    apple.AppleB = false;

    StartTimers();
    DrawBackground();

    while(1)
    {
        StartMenu();

        TimerStuff();

        if(player.PlayerSpawn == true) // So player draws when game starts
        {
            DrawPlayer();
            player.PlayerSpawn = false;
        }
        else if(apple.AppleB == false) // Spawn new apple
        {
            srand(GetTickCount());                      // Randomizer
            apple.RandomAppleX =  ((rand() % 100) + 5); // 5-100?

            apple.AppleX1 = apple.RandomAppleX;
            apple.AppleX2 = apple.AppleX1 + 1;

            apple.AppleB = true;
        }
        else if((GetAsyncKeyState(0x41)) && ((PlayerElapsed > 5))) // If press A
        {
            ErasePlayer();
            player.MovePlayerLeft();
            DrawBackground();
            DrawPlayer();
            DrawApple();
            PlayerTimer1 = GetTickCount(); // Reset player timer
            PlayerElapsed = 0;             // Reset player timer
        }
        else if((GetAsyncKeyState(0x44)) && ((PlayerElapsed > 5))) // If press D
        {
            ErasePlayer();
            player.MovePlayerRight();
            DrawBackground();
            DrawPlayer();
            DrawApple();
            PlayerTimer1 = GetTickCount(); // Reset player timer
            PlayerElapsed = 0;             // Reset player timer
        }
        else if(AppleFallElapsed > apple.AppleSpeed) // Make apple fall to its dooooom :O:O:O:O
        {
            EraseApple();
            apple.MoveAppleDown();
            DrawBackground();
            DrawPlayer();
            DrawApple();
            AppleFallTimer1 = GetTickCount(); // Reset apple fall timer
            AppleFallElapsed = 0;             // Reset apple fall timer
        }
        else if(((apple.AppleY3 == player.SideY1)) && ((apple.AppleX1 >= player.LeftSideX) && (apple.AppleX1 <= player.RightSideX))) // If apple falls on player
        {
            thread CrunchT(CrunchV);
            EraseApple();
            Score++;
            apple.ResetApple();
            apple.AppleB = false; // Spawn new apple
            AppleFallTimer1 = GetTickCount(); // Reset apple fall timer
            AppleFallElapsed = 0;             // Reset apple fall timer
            CrunchT.join();
        }
        else if(AppleSpeedElapsed > 5000) // Game difficulty increases
        {
            apple.AppleSpeed = apple.AppleSpeed - 10;
            AppleSpeedTimer1 = GetTickCount();   // Reset apple speed timer
            AppleSpeedElapsed = 0;               // Reset apple speed timer
        }
        else if(apple.AppleY3 == 27) // If apple hit the ground
        {
            apple.ResetApple();
            apple.AppleSpeed = 100; // Reset apples speed to normal
            AppleFallTimer1 = GetTickCount(); // Reset apple fall timer
            AppleFallElapsed = 0;             // Reset apple fall timer
            LOL = false;
        }
        switch(player.LeftSideX)
        {
            case 1: player.MovePlayerRight(); break;
            case 107: player.MovePlayerLeft(); break;
        }
    }
}

void DrawBackground()
{
    for(int x; x < 29; x++)
    {
        Draw("                                                                                                                    ", 0, x, 48);
    }

    // Sun
    Draw("        ", 108, 0, 224);
    Draw("       ", 109, 1, 224);
    Draw("      ", 110, 2, 224);
    Draw("     ", 111, 3, 224);
    Draw("    ", 112, 4, 224);
    Draw("   ", 113, 5, 224);

    // Sun beams
    Draw("    ", 102, 1, 224);
    Draw("    ", 98, 2, 224);
    Draw("   ", 105, 3, 224);
    Draw("   ", 102, 4, 224);
    Draw("    ", 107, 6, 224);
    Draw("   ", 104, 7, 224);

    Draw("                                                                                                                    ", 0, 28, 32);  // Grass
    Draw("                                                                                                                    ", 0, 29, 192); // Dirt
    Draw("                                                                                                                    ", 0, 30, 192); // Dirt
}

void StartMenu()
{
    while(LOL == false)
    {
        Draw("                          ", 40, 10, 112);
        Draw("     CATCH THAT APPLE!    ", 40, 11, 116);
        Draw("                          ", 40, 12, 112);
        Draw(" - A/D to move            ", 40, 13, 114);
        Draw("                          ", 40, 14, 112);
        Draw(" - ENTER to start         ", 40, 15, 121);
        Draw("                          ", 40, 16, 112);
        Draw("                          ", 40, 17, 112);

        Draw("Score: ", 42, 17, 112);
        cout << Score << endl;

        if(GetAsyncKeyState(VK_RETURN))
        {
            EraseAll();
            Score = 0;
            StartOrEndMenu = true; // Next time go through else if
            apple.AppleB = false;      // Spawn new apple
            LOL = true;            // Leave the while loop
        }
    }
}

void StartTimers()
{
    PlayerTimer1 = GetTickCount();      // Start player timer
    AppleFallTimer1 = GetTickCount();   // Start fall apple timer
    AppleSpeedTimer1 = GetTickCount();  // Start speed apple timer
}

void TimerStuff()
{
    PlayerTimer2 = GetTickCount();                             // Player timer stuff
    PlayerElapsed =  PlayerTimer2 -  PlayerTimer1;             // Player timer stuff

    AppleFallTimer2 = GetTickCount();                          // Apple fall timer stuff
    AppleFallElapsed =  AppleFallTimer2 -  AppleFallTimer1;    // Apple fall timer stuff

    AppleSpeedTimer2 = GetTickCount();                         // Apple speed timer stuff
    AppleSpeedElapsed =  AppleSpeedTimer2 -  AppleSpeedTimer1; // Apple speed timer stuff
}

void EraseAll()
{
    for(int i; i < 31; i++)
    {
        Draw("                                                                                                         ", 0, i, 0);
    }
}

void EraseApple()
{
    Draw(" ", apple.AppleX2, apple.AppleY1, 0);
    Draw("   ", apple.AppleX1, apple.AppleY2, 0);
    Draw("   ", apple.AppleX1, apple.AppleY3, 0);
}

void DrawApple()
{
    Draw(" ", apple.AppleX2, apple.AppleY1, BackgroundGreen);
    Draw("   ", apple.AppleX1, apple.AppleY2, BackgroundRed);
    Draw("   ", apple.AppleX1, apple.AppleY3, BackgroundRed);
}

void ErasePlayer()
{
    Draw(" ", player.LeftSideX, player.SideY1, 0);
    Draw(" ", player.LeftSideX, player.SideY2, 0);
    Draw(" ", player.LeftSideX, player.SideY3, 0);
    Draw(" ", player.LeftSideX, player.SideY4, 0);
    Draw("        ", player.BottomSideX, player.BottomSideY, 0);
    Draw(" ", player.RightSideX, player.SideY1, 0);
    Draw(" ", player.RightSideX, player.SideY2, 0);
    Draw(" ", player.RightSideX, player.SideY3, 0);
    Draw(" ", player.RightSideX, player.SideY4, 0);
}

void DrawPlayer()
{
    Draw(" ", player.LeftSideX, player.SideY1, BackgroundGray);
    Draw(" ", player.LeftSideX, player.SideY2, BackgroundGray);
    Draw(" ", player.LeftSideX, player.SideY3, BackgroundGray);
    Draw(" ", player.LeftSideX, player.SideY4, BackgroundGray);
    Draw("        ", player.BottomSideX, player.BottomSideY, BackgroundGray);
    Draw(" ", player.RightSideX, player.SideY1, BackgroundGray);
    Draw(" ", player.RightSideX, player.SideY2, BackgroundGray);
    Draw(" ", player.RightSideX, player.SideY3, BackgroundGray);
    Draw(" ", player.RightSideX, player.SideY4, BackgroundGray);
}

void Draw(string Str, int X, int Y, WORD color)
{
	HANDLE OutputH;
	COORD position = { X, Y };
	OutputH = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(OutputH, color);
	SetConsoleCursorPosition(OutputH, position);
	cout << Str;
}
