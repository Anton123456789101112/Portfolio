#include <iostream>
#include <random>

int randomFoo()
{
    // Massa skit, skapa ett tal från 1-15
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dist(1, 15);

    return dist(gen);
}

int getValue()
{
    int i;
    std::cin >> i;

    return i;
}

void checkAnswer(int a, int b, int c)
{
    if(a == b * c)
        std::cout << "Ratt!\n";

    else
        std::cout << "Fel!\n";
}

char continueYesNo()
{
    std::cout << "Vill du fortsatta? (j/n)\n";
    char c{};
    std::cin >> c;
    
    return c;
}

int main()
{
    while(true)
    {
        int randNum1 { randomFoo() };
        int randNum2 { randomFoo() };

        std::cout << randNum1 << " * " << randNum2 << " = ";

        int input { getValue() };

        checkAnswer(input, randNum1, randNum2);

        char choice { continueYesNo() };
        if(choice != 'j' && choice != 'J')
            break;
    }

    return 0; 
}
